#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 15:25:36 2019

@author: chabhaidri
"""

"""
IDRI Chabha
EL HAJJAJI Oumaima           
"""
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sklearn.datasets as datasets
from scipy.stats import linregress


print("******************** EXO01:Descente de gradient ***********************")

#1.Calculez l’expression analytique de la fonction de E    
    
def E(x):
    return (x-1)*(x-2)*(x-3)*(x-5)

#la dérivée de E
    
def de(x):
    return 4*(x**3)-11*(x**2)+41*x-61

#2.Implémentez l’algorithme DG
    
""" ---------Idée de l'algo----------------
    -initialiser x
    -répéter x(i+1) = x(i) − ηE′(xi)
     jusqu'à convergence de E'(xi)                        
""" 
    
""" définiiton d'argument:
        iter_max=itération maximum à faire 
        epsilon=précision du résultat
        x0=le point initialiser donné par l'utilisateur
        eta=η(taux d'apprentissage) 
        de=la dérivée de f   
"""

def DG(iter_max,epsilon,x0,eta,de):
    x=x0
    for i in range(iter_max):
    
        x_previous=x
        x=x_previous-(eta*de(x_previous))
        
        if(x-x_previous)<epsilon:
        
            return [x,i]
    
    return [x, iter_max]

#3.tester l'algorithme DG
    
print("\n                 *****Les valeurs de x(min)et l'itération*****")
f1=DG(1000,0.01,5,0.001,de)
print(f1) 

f2=DG(1000,0.01,5,0.01,de)
print(f2)

f3=DG(1000,0.01,5,0.1,de)
print(f3)

f4=DG(1000,0.01,5,0.17,de)
print(f4)

f5=DG(1000,0.01,5,1,de)
print(f5)

f6=DG(1000,0.01,0,0.001,de)
print(f6)
print("\n")

#4.Afficher le minimum trouvée,E(xmin) ainsi que le nombre d'itérations

#créer l'objet parser
parser = argparse.ArgumentParser()
arguments = parser.parse_args()

# affectation des valeurs pour epsilon et max 
       
epsilon=0.01
max_plus=1000

arguments = [{'x0': 5,'eta': 0.001},
            {'x0': 5,'eta': 0.01},
            {'x0': 5,'eta': 0.1},
            {'x0': 5,'eta': 0.17},
            {'x0': 5,'eta': 1},
            {'x0': 0,'eta': 0.001}]

#tester la fonctoin DG

print("\n    ***Le minimum trouvée,E(xmin) ainsi que Le nombre d'itérations*** \n")

gradient_list = []
for i in range(len(arguments)):
    gd1=DG(iter_max = max_plus, epsilon = epsilon, de=de, **arguments[i])
    gradient_list.append(gd1)
    print("[x0:{} eta:{}] - [(x,i):{}] - E(xmin) = {}\n".format(arguments[i]['x0'], arguments[i]['eta'], gd1, E(gd1[0])))

#6.Testez votre algorithme avec d’autres valeurs de ε et nb_max   
 
#on remarque que la valueur de DG ne change pas en changeant le epsilon ainsi le nombre d'itération

print("\n  ***** Avec une autre valeur pour epsilon et pour nombremax: ")
f11=DG(10000000,0.00001,5,0.001,de)
print(f11)
 
f22=DG(5,0.0002,5,0.01,de)
print(f22)


"""******************************************************************************
   ******************************************************************************
   ******************************************************************************"""
   
print("\n***EXO02:Descente de gradient pour la régression linéaire***\n ")

 
#1.Calculez les dérivées partielles de E

def g(x, y, a, b):
    return (a*x+b-y)**2

def dg(x, y, a, b):
    return {'da': 2*(a*x**2+b*x-y*x), 'db': 2*(a*x+b-y)}

#2.Implémentez l’algorithme DG pour la fonction F
    
#nb_sample=taille de l'échantillon
    
def DG_descent_LR(iter_max, epsilon, eta, x, y, df):

    nb_sample = x.shape[0]
    range_sample = range(1, nb_sample)
    
    # Génération du jeu de données a et b

    a = np.random.random(x.shape[1])
    b = np.random.random(x.shape[1])
    
    #fonction de coût à minimiser
    G = sum([a*x[j]+b-y[j] for j in range_sample])
    

    for i in range(iter_max):
        
        # Gradient du paramètre a
        a_gradient = sum([2*(a*x[j]**2+b*x[j]-y[j]*x[j]) for j in range_sample])
        
        # Gradient du paramètre b
        b_gradient = sum([2*(a*x[j]+b-y[j]) for j in range_sample])

        #Descente de gradient
        aa = a - eta * a_gradient
        bb = b - eta * b_gradient
        
        #mise à jour des variables a et b
        a = aa
        b = bb
        
        #la fonction d'erreur
        g = sum([a*x[j]+b-y[j] for j in range_sample])

        if abs(G-g) <= epsilon:
            return ({'a': a, 'b': b}, i)
            
        G = g

    return ({'a': a, 'b': b}, iter_max)


#3.Appliquez l’algorithme implémenté
    
nb_sample = 100    
arguments = [{'eta': 0.001,'iter_max': 100},
            {'eta': 0.001,'iter_max': 500},
            {'eta': 0.001,'iter_max': 1000},
            {'eta': 0.01,'iter_max': 1000},
            {'eta': 1,'iter_max': 1000}]

# Génération du jeu de données
j1, j2 = datasets.make_regression(n_samples=nb_sample, n_features=1)

# Exécution de l'algorithme
DG_reg1 = DG_descent_LR(epsilon = epsilon, x = j1, y = j2, df = dg, **arguments[0])
print(DG_reg1)

#6.Visualisez le jeu de données généré

plt.figure()
plt.scatter(j1,j2)

line_x = [min(j1), max(j1)]
line_y = (DG_reg1[0]['a']*i+DG_reg1[0]['b'] for i in line_x)
#plt.plot(line_x,line_y)


# Exo1. 5.Visualisez l’évolution des minimums de la fonction E
    
#création de jeu de données à partir de la liste gradient_list
 
print("\n  *****Le tableau df *****")    
df=pd.DataFrame(gradient_list)  
print(df)

print("\n       *****Visualisez l’évolution des minimums et de E(x) ***** \n  ")
  
plt.figure()  
plt.scatter(gradient_list,gradient_list)  
plt.title('’évolution des minimums et de E(x) ')









